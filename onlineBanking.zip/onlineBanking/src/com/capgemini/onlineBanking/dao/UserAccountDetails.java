package com.capgemini.onlineBanking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.onlineBanking.exception.onlineBankingException;

//import com.capgemini.onlineBanking.dao;
//import com.capgemini.onlineBanking;

public class UserAccountDetails implements IUsersAccountsDb {

	@Override
	public long validateUser(String username, String password) throws onlineBankingException{
		long account = 0;
		String pwd = null;
		long result = 0;
		 try{ 
			System.out.println(username+"        "+password);
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@localhost:1521:xe","sharma","admin");
			//System.out.println("hello");
			  
			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select accountno,password from bankcustomers where username='"+username+"'");
			//ResultSet rs=stmt.executeQuery("select * from rechargeplans"); 
			if(rs!=null){
				
				while(rs.next()){
					
					account=rs.getLong(1);
					pwd=rs.getString(2);
					System.out.println(pwd);
					
				}
			}
			if(pwd.equals(password)){
				
				result=account;
			}
			else{
				System.out.println("hello");
				throw new onlineBankingException("Details not Matched");
				//System.out.println("hello");
			}
			System.out.println("hello");
			//step5 close the connection object  
			con.close();  
		 }
		 catch(SQLException e){
			 throw new onlineBankingException("Database Connection error");
		 }
		 catch(ClassNotFoundException c){
			 throw new onlineBankingException("Database driver not found");
		 }
		 catch(NullPointerException ne){
			 throw new onlineBankingException("No details matched with given username");
		 }
		 
			
			return result;
			  
		
	}

}
