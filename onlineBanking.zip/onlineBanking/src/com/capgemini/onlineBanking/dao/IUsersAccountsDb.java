package com.capgemini.onlineBanking.dao;

import java.sql.SQLException;

import com.capgemini.onlineBanking.exception.onlineBankingException;

public interface IUsersAccountsDb {
	//public long validateUser(String username, String password) throws onlineBankingException;

	public long validateUser(String username, String password) throws onlineBankingException;
	
}
