package com.capgemini.onlineBanking.service;

import java.sql.SQLException;

import com.capgemini.onlineBanking.dao.IUsersAccountsDb;
import com.capgemini.onlineBanking.dao.UserAccountDetails;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public class UserServiceDetails implements IBankServices {

	@Override
	public long validateUser(String username, String password) throws onlineBankingException{
		IUsersAccountsDb iad=new UserAccountDetails();
		long account=iad.validateUser(username,password);
		return account;
	}

}
