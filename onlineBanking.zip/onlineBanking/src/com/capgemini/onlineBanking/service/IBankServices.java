package com.capgemini.onlineBanking.service;

import java.sql.SQLException;

import com.capgemini.onlineBanking.exception.onlineBankingException;

public interface IBankServices {

	public long validateUser(String username, String password) throws onlineBankingException;
	
}
