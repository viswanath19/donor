package com.capgemini.onlineBanking.pi;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.onlineBanking.exception.onlineBankingException;
import com.capgemini.onlineBanking.service.IBankServices;
import com.capgemini.onlineBanking.service.UserServiceDetails;

public class Client {

	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		System.out.println("Welcome to Online Banking");
		System.out.println("Choose your option 1.Login 2.Register");
		int choice;
		Scanner sc=new Scanner(System.in);
		choice=sc.nextInt();
		if(choice==1){
			System.out.println("Enter your username");
			String username=sc.next();
			System.out.println("Enter your password");
			String password=sc.next();
			IBankServices ibs=new UserServiceDetails();
			try{
			long account=ibs.validateUser(username,password);
			System.out.println(account);
			}
			catch(onlineBankingException o){
				System.out.println(o.getMessage());
			}
		}

	}

}
