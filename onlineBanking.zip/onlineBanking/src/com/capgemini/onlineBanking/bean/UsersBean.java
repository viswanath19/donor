package com.capgemini.onlineBanking.bean;

public class UsersBean {
	private long accountno;
	private String name;
	private long mobile;
	private String Address;
	private long adharno;
	private String panno;
	private String username;
	private String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getAccountno() {
		return accountno;
	}
	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public long getAdharno() {
		return adharno;
	}
	public void setAdharno(long adharno) {
		this.adharno = adharno;
	}
	public String getPanno() {
		return panno;
	}
	public void setPanno(String panno) {
		this.panno = panno;
	}
	public UsersBean(long accountno, String name, long mobile, String address, long adharno, String panno) {
		super();
		this.accountno = accountno;
		this.name = name;
		this.mobile = mobile;
		Address = address;
		this.adharno = adharno;
		this.panno = panno;
	}
	

}
