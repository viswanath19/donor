package com.bean;

public class BillBean {
	private long consumer_no;
	private String consumer_name;
	private String address;
	public long getConsumer_no() {
		return consumer_no;
	}
	public void setConsumer_no(long consumer_no) {
		this.consumer_no = consumer_no;
	}
	public String getConsumer_name() {
		return consumer_name;
	}
	public void setConsumer_name(String consumer_name) {
		this.consumer_name = consumer_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
