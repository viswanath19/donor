package com.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBUtil {
	private static Connection connection;
	public static Connection getConnection(){
	try{
		InitialContext ic=new InitialContext();
		DataSource ds=ic.doLookup("java:/OracleDs");
		connection=ds.getConnection();
	}
	catch(Exception e){
		
	}
	return connection;
	}

}
