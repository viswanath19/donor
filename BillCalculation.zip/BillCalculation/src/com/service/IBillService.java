package com.service;

import java.util.List;

import com.bean.BillBean;

public interface IBillService {

	List<BillBean> listConsumers();

}
