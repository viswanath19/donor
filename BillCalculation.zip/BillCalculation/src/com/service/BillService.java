package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.BillBean;
import com.dao.Billdao;
import com.dao.IBilldao;

public class BillService implements IBillService{

	@Override
	public List<BillBean> listConsumers() {
		IBilldao ibd=new Billdao();
		List<BillBean> consumers=new ArrayList<BillBean>(20);
		consumers=ibd.listConsumers();
		return consumers;
	}

}
