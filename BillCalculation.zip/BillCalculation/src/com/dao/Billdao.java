package com.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bean.BillBean;
import com.util.DBUtil;

public class Billdao implements IBilldao {

	@Override
	public List<BillBean> listConsumers() {
		Connection con=null;
		Statement stmt=null;
		//String consumer_no[]=new String[10];
		//String consumer_names[]=new String[10];
		//String address[]=new String[10];
		//int i=0,j=0,k=0;
		//StringBuilder sb=new StringBuilder();
		List<BillBean> consumers=new ArrayList<BillBean>(25);
		try{
			con=DBUtil.getConnection();
			stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from consumers");
			
			if(rs!=null){
				while(rs.next()){
					BillBean b=new BillBean();
					long cno=rs.getLong(1);
					String cname=rs.getString(2);
					String addr=rs.getString(3);
					b.setConsumer_no(cno);
					b.setConsumer_name(cname);
					b.setAddress(addr);
					consumers.add(b);
				}
			}
			
			//sb.append(consumer_no+"<BR>"+consumer_names+"<BR>"+address);
		}
		catch(Exception e){
			
		}
		return consumers;
	}

}
