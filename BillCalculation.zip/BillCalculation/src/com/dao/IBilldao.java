package com.dao;

import java.util.List;

import com.bean.BillBean;

public interface IBilldao {

	List<BillBean> listConsumers();

}
