package com.capgemini.recharge.pi;

import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.recharge.bean.RechargeBean;
import com.capgemini.recharge.dao.IRechargeInterface;
import com.capgemini.recharge.dao.RechargeDataBase;
import com.capgemini.recharge.service.Details;
import com.capgemini.recharge.service.IRechargingInterface;

public class UserInput {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		IRechargingInterface ie=new Details();
		String name;
		boolean validatename;
		boolean validatePlan;
		long mobile;
		do{
		System.out.println("Enter the name");
		name=sc.next();
		validatename=ie.validateName(name);
		}while(validatename==false);
		boolean validatemobile;
		//if(validateName==true){
		do{
		System.out.println("Enter the mobile number");
		mobile=sc.nextLong();
		validatemobile=ie.validateMobile(mobile);
		}while(validatemobile==false);
		
		
		
		RechargeBean rb=new RechargeBean();
		//rb.setName(name);
		//rb.setMobileno(mobile);
		//System.out.println(rb.getName());
		
		String details=ie.displayRechargePlans();
		System.out.println(details);
		String planname;
		do{
		System.out.println("Enter the plan Name From above Plans");
		planname=sc.next();
		validatePlan = ie.validatePlan(planname);
		}while(validatePlan==true);
		//rb.setPlanname(planname);
		int money=ie.getAmount(planname);
		//System.out.println(money);
		//rb.setAmount(money);
		if(money!=0){
		rb.setStatus("success");
		long rechId=ie.addUserDetails(name,mobile,rb.getStatus(),planname,money);
		//long rechId=ie.addUserDetails(rb.getName(),rb.getMobileno(),rb.getStatus(),rb.getPlanname(),rb.getAmount());
		System.out.println("Your Recharge is SuccessFull and your recharge Id is: "+rechId);
		System.out.println("Check Your Status");
		System.out.println("Enter Your Recharge Id");
		long rechargeid=sc.nextLong();
		String info=ie.getRechargeDetails(rechargeid,rb);
		//System.out.println(info);
		System.out.println("Recharge Id is: "+rb.getRechid());
		System.out.println("Name is : "+rb.getName());
		System.out.println("Mobile number is: "+rb.getMobileno());
		System.out.println("Plan Amount is: "+rb.getAmount());
		System.out.println("Plan Name is: "+rb.getPlanname());
		System.out.println("Status of Recharge: "+rb.getStatus());
		}
		else{
			rb.setStatus("Fail");
			long rechId=ie.addUserDetails(name,mobile,rb.getStatus(),planname,money);
			//long rechId=ie.addUserDetails(rb.getName(),rb.getMobileno(),rb.getStatus(),rb.getPlanname(),rb.getAmount());
			System.out.println("Your Recharge is on hold and your recharge Id is: "+rechId);
			System.out.println("Check Your Status");
			System.out.println("Enter Your Recharge Id");
			long rechargeid=sc.nextLong();
			String info=ie.getRechargeDetails(rechargeid,rb);
			System.out.println(info);
			if(info.contains("No details found with recharge id")){
				System.out.println(info);
			}
			
		}
		}
	}

