package com.capgemini.recharge.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.recharge.bean.RechargeBean;
import com.capgemini.recharge.dao.IRechargeInterface;
import com.capgemini.recharge.dao.RechargeDataBase;

public class Details implements IRechargingInterface{

	@Override
	public String displayRechargePlans() {
		IRechargeInterface ie=new RechargeDataBase();
		String details=ie.displayRechargePlans();
		return details;
	}

	@Override
	public int getAmount(String planname) {
		IRechargeInterface ie=new RechargeDataBase();
		int amount=ie.getAmount(planname);
	
		return amount;
	}

	@Override
	public long addUserDetails(String name, long mobileno, String status,String planname, int amount) throws SQLException {
		IRechargeInterface ie=new RechargeDataBase();
		long rechid=ie.addUserDetails(name, mobileno,status, planname, amount);
		return rechid;
		
	}

	@Override
	public String getRechargeDetails(long rechId,RechargeBean rb) {
		IRechargeInterface ie=new RechargeDataBase();
		String rechargeInfo=ie.getRechargeDetails(rechId,rb);
		return rechargeInfo;
	}

	@Override
	public boolean validateName(String name) {
		String regx = "^[a-zA-Z]{3,}$";
	    Pattern pattern = Pattern.compile(regx,Pattern.CASE_INSENSITIVE);
	    Matcher matcher = pattern.matcher(name);
	    return matcher.find();
	}

	@Override
	public boolean validateMobile(long mobile) {
		String regx = "\\d{10}";
		Pattern pattern = Pattern.compile(regx);
		String s=String.valueOf(mobile);
		 Matcher matcher = pattern.matcher(s);
		 return matcher.find();
	}

	@Override
	public boolean validatePlan(String planname) {
		boolean plan = false;
		if(planname=="RC99"){
			plan=true;
		}
		else if(planname=="RC150"){
			plan=true;
		}
		else if(planname=="RC299"){
			plan=true;
		}
		else if(planname=="RC500"){
			plan=true;
		}
		else{
			plan=false;
		}
		return plan;
	}
	

}
