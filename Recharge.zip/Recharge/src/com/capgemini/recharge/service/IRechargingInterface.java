package com.capgemini.recharge.service;

import java.sql.SQLException;

import com.capgemini.recharge.bean.RechargeBean;

public interface IRechargingInterface {
	public String displayRechargePlans();
	public int getAmount(String planname);
	public long addUserDetails(String name, long mobileno, String status,String planname, int amount) throws SQLException;
	//public String getRechargeDetails(long rechId);
	public String getRechargeDetails(long rechargeid, RechargeBean rb);
	public boolean validateName(String name);
	public boolean validateMobile(long mobile);
	public boolean validatePlan(String planname);
	
}