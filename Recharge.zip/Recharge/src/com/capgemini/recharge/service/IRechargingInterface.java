package com.capgemini.recharge.service;

public interface IRechargingInterface {
	public String displayRechargePlans();
	public int getAmount(String planname);
}
