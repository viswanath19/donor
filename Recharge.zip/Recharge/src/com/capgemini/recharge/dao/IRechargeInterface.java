package com.capgemini.recharge.dao;

import java.sql.SQLException;

import com.capgemini.recharge.bean.RechargeBean;

public interface IRechargeInterface {
	public String displayRechargePlans();
	public int getAmount(String planname);
	public long addUserDetails(String name, long mobileno, String status,String planname,int amount) throws SQLException;
	public String getRechargeDetails(long rechId,RechargeBean rb);
	

}

