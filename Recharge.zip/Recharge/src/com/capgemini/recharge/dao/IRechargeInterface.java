package com.capgemini.recharge.dao;

public interface IRechargeInterface {
	public String displayRechargePlans();
	public int getAmount(String planname);
	

}
