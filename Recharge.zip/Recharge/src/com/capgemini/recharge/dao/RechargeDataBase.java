package com.capgemini.recharge.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;  

import com.capgemini.recharge.bean.RechargeBean;
	
public class RechargeDataBase implements IRechargeInterface{  
	@Override
	public String displayRechargePlans(){
	//System.out.println("hello");
	String planname = null;
	int amount=0;
	String msg = null;
	StringBuilder sb=new StringBuilder();
	try{  
	//step1 load the driver class  
	Class.forName("oracle.jdbc.driver.OracleDriver");  
	  
	//step2 create  the connection object  
	Connection con=DriverManager.getConnection(  
	"jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1126", "training1126");  
	  
	//step3 create the statement object  
	Statement stmt=con.createStatement();  
	  
	//step4 execute query  
	ResultSet rs=stmt.executeQuery("select * from recharge"); 
	if(rs!=null){
		
		while(rs.next()){
			//System.out.println("hrllo");
			
			planname=rs.getString(1);
			amount=rs.getInt(2);
			sb.append(planname+"            "+Integer.toString(amount)+"\n");
			//System.out.println(details);
			
		}
	}
	//step5 close the connection object  
	con.close();  
	  
	}catch(Exception e){ 
		msg=e.getMessage();
	}
	return sb.toString();
	  
	}

	@Override
	public int getAmount(String planname) {
		int amount=0;
		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con1=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1126", "training1126");  
			  
			//step3 create the statement object  
			Statement stmt=con1.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select amount from recharge where plan='"+planname+"'"); 
			if(rs!=null){
				while(rs.next()){
					amount = rs.getInt(1);
					//System.out.println(details);
					
				}
			}
			//step5 close the connection object  
			con1.close();  
			  
			}catch(Exception e){ 
				String msg = e.getMessage();
			}
		return amount;
	}
	@Override
	public long addUserDetails(String name,long mobile,String status,String planName,int amount) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1126","training1126");
		String s1="insert into rechargeInfo values(?,?,?,?,?,?)";
		PreparedStatement s=conn.prepareStatement(s1);
		String s2="select rec_seq.nextval from dual";
		java.sql.Statement sw=conn.createStatement();
		ResultSet r1=sw.executeQuery(s2);
		int val=0;
		while(r1.next())
		{
			val=r1.getInt(1);
		}
		//s.executeUpdate();
		s=conn.prepareStatement(s1);
		s.setInt(1,val);
		s.setString(2,name);
		s.setLong(3, mobile);
		s.setString(4,status);
		s.setString(5,planName);
		s.setInt(6,amount);
		s.executeUpdate();
		return val;
	}
	@Override
	public String getRechargeDetails(long rechId,RechargeBean rb) {
		String planname = null;
		int amount=0;
		String name=null;
		String status=null;
		long mobileno=0;
		long rechid=0;
		StringBuilder sb=new StringBuilder();
		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con1=DriverManager.getConnection(  
			"jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg1126", "training1126");  
			  
			//step3 create the statement object  
			Statement stmt=con1.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select * from rechargeInfo where rechid='"+rechId+"'"); 
			if(rs!=null){
				while(rs.next()){
					rechid=rs.getLong(1);
					name=rs.getString(2);
					mobileno=rs.getLong(3);
					status=rs.getString(4);
					planname=rs.getString(5);
					amount=rs.getInt(6);
					sb.append(rechid+"      "+name+"      "+mobileno+"          "+status+"        "+planname+"            "+Integer.toString(amount)+"\n");
					//System.out.println(details);
					
				}
			}
			if(rechid==0){
				throw new ArithmeticException("No details found with recharge id "+rechId);  
			}
			else{
			rb.setRechid(rechId);
			rb.setName(name);
			rb.setAmount(amount);
			rb.setMobileno(mobileno);
			rb.setStatus(status);
			rb.setPlanname(planname);
			System.out.println(rb.getName());
			}
			//step5 close the connection object  
			con1.close();  
			  
			}catch(Exception e){ 
				sb.append(e.getMessage());
			}
		return sb.toString();
	}

}

