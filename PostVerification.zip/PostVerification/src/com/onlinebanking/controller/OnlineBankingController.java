package com.onlinebanking.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class OnlineBankingController
 */
@WebServlet("/OnlineBankingController")
public class OnlineBankingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OnlineBankingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("action");
		String option=request.getParameter("name");
		PrintWriter out=response.getWriter();
		System.out.println(operation);
		if(option!=null&&option.equalsIgnoreCase("helloUser")){
			//PrintWriter out=response.getWriter();
			String userId=request.getParameter("userId");
			out.println(userId);
		}
		else{
			//PrintWriter out=response.getWriter();
			out.println("Not reached");
		}
		if(operation!=null&&operation.equalsIgnoreCase("submit")){
			String user=request.getParameter("userId");
			request.setAttribute("user",user);
			RequestDispatcher rd=request.getRequestDispatcher("/nextPage.jsp");
			rd.forward(request, response);
		}
	}

}
