package com.capgemini.electricityBillException;

public class electricityBillException extends Exception {
	public electricityBillException(String msg){
		super(msg);
	}
}
