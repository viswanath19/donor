package com.dao;

import java.util.List;

import com.bean.EBillBean;

public interface IEBilldao {
	List<EBillBean> listConsumers();

	List<EBillBean> getConsumerDetails(String consumerNo);
	List<EBillBean> getBillDetails(String consumerNo);
}
