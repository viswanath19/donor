package com.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bean.EBillBean;
import com.util.DBUtil;

public class EBilldao implements IEBilldao

{

	@Override
	public List<EBillBean> listConsumers() {
		Connection con=null;
		Statement stmt=null;
		//String consumer_no[]=new String[10];
		//String consumer_names[]=new String[10];
		//String address[]=new String[10];
		//int i=0,j=0,k=0;
		//StringBuilder sb=new StringBuilder();
		List<EBillBean> consumers=new ArrayList<EBillBean>(25);
		try{
			con=DBUtil.obtainConnection();
			stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from consumers");
			
			if(rs!=null){
				while(rs.next()){
					EBillBean b=new EBillBean();
					long cno=rs.getLong(1);
					String cname=rs.getString(2);
					String addr=rs.getString(3);
					b.setConsumerNo(cno);
					b.setConsumername(cname);
					b.setAddress(addr);
					consumers.add(b);
				}
			}
			
			//sb.append(consumer_no+"<BR>"+consumer_names+"<BR>"+address);
		}
		catch(Exception e){
			
		}
		return consumers;
	}

	@Override
	public List<EBillBean> getConsumerDetails(String consumerNo) {
		Connection con=null;
		Statement stmt=null;
		//String consumer_no[]=new String[10];
		//String consumer_names[]=new String[10];
		//String address[]=new String[10];
		//int i=0,j=0,k=0;
		//StringBuilder sb=new StringBuilder();
		List<EBillBean> consumers=new ArrayList<EBillBean>(25);
		try{
			con=DBUtil.obtainConnection();
			stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from consumers where consumer_num='"+consumerNo+"'");
			if(rs!=null){
				while(rs.next()){
					EBillBean b=new EBillBean();
					long cno=rs.getLong(1);
					String cname=rs.getString(2);
					String addr=rs.getString(3);
					b.setConsumerNo(cno);
					b.setConsumername(cname);
					b.setAddress(addr);
					consumers.add(b);
				}
			}
			
			//sb.append(consumer_no+"<BR>"+consumer_names+"<BR>"+address);
		}
		catch(Exception e){
			
		}
		return consumers;
	}

	@Override
	public List<EBillBean> getBillDetails(String consumerNo) {
		
		Connection con=null;
		Statement stmt=null;
		//String consumer_no[]=new String[10];
		//String consumer_names[]=new String[10];
		//String address[]=new String[10];
		//int i=0,j=0,k=0;
		//StringBuilder sb=new StringBuilder();
		List<EBillBean> consumers=new ArrayList<EBillBean>(25);
		try{
			con=DBUtil.obtainConnection();
			stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from billdetails where consumer_num='"+consumerNo+"'");
			if(rs!=null){
				while(rs.next()){
					EBillBean b=new EBillBean();
					
					int billno=rs.getInt(1);
					long cno=rs.getLong(2);
					float cmr=rs.getFloat(3);
					float units=rs.getFloat(4);
					float amount=rs.getFloat(5);
					String billdate=rs.getString(6);
					
					b.setConsumerNo(cno);
					b.setBillno(billno);
					b.setCmr(cmr);
					b.setUnits(units);
					b.setAmount(amount);
					b.setBilldate(billdate);
					consumers.add(b);
				}
			}
			
			//sb.append(consumer_no+"<BR>"+consumer_names+"<BR>"+address);
		}
		catch(Exception e){
			
		}
		return consumers;

	}

}
