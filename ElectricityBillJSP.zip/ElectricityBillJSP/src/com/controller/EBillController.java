package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.EBillBean;
import com.service.EBillService;
import com.service.IEBillService;

/**
 * Servlet implementation class EBillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String operation=request.getParameter("action");
		if(operation.equals("listConsumers")){
				IEBillService ibs=new EBillService();
				List<EBillBean> consumers=new ArrayList<EBillBean>(25);
				consumers=ibs.listConsumers();
				request.setAttribute("consumers", consumers);
				RequestDispatcher rd=request.getRequestDispatcher("/viewConsumers.jsp");
				rd.forward(request, response);
		}
		else if(operation.equals("getBillDetails")){
			String consumerNo=request.getParameter("consumer_id");
			//out.println(consumerNo);
			IEBillService ibs=new EBillService();
			List<EBillBean> consumerdetails=new ArrayList<EBillBean>(25);
			consumerdetails=ibs.getConsumerDetails(consumerNo);
			request.setAttribute("consumerDetails", consumerdetails);
			RequestDispatcher rd=request.getRequestDispatcher("/ConsumerDetails.jsp");
			rd.forward(request, response);
		}
		else if(operation.equals("showBills")){
			//out.println("hello");
			String consumerNo=request.getParameter("consumer_no");
			out.println(consumerNo);
			System.out.println(consumerNo);
			out.println("hello");
			IEBillService ibs=new EBillService();
			List<EBillBean> billDetails=new ArrayList<EBillBean>(25);
			billDetails=ibs.getBillDetails(consumerNo);
			request.setAttribute("bills", billDetails);
			RequestDispatcher rd=request.getRequestDispatcher("/ViewBills.jsp");
			rd.forward(request, response);
			out.println(billDetails);
			
		}
	}

}
