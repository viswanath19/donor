package com.bean;

public class EBillBean {
	private long consumerNo;
	private String consumername;
	private String address;
	private float cmr;
	private float units;
	private float amount;
	private String billdate;
	private int billno;
	public int getBillno() {
		return billno;
	}
	public void setBillno(int billno) {
		this.billno = billno;
	}
	public float getCmr() {
		return cmr;
	}
	public void setCmr(float cmr) {
		this.cmr = cmr;
	}
	public float getUnits() {
		return units;
	}
	public void setUnits(float units) {
		this.units = units;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getBilldate() {
		return billdate;
	}
	public void setBilldate(String billdate) {
		this.billdate = billdate;
	}
	public long getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(long consumerNo) {
		this.consumerNo = consumerNo;
	}
	public String getConsumername() {
		return consumername;
	}
	public void setConsumername(String consumername) {
		this.consumername = consumername;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
