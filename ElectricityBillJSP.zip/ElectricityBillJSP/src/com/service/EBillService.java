package com.service;

import java.util.ArrayList;
import java.util.List;

import com.bean.EBillBean;
import com.bean.EBillBean;
import com.dao.EBilldao;
import com.dao.EBilldao;
import com.dao.IEBilldao;
import com.dao.IEBilldao;

public class EBillService implements IEBillService{

	@Override
	public List<EBillBean> listConsumers() {
		IEBilldao ibd=new EBilldao();
		List<EBillBean> consumers=new ArrayList<EBillBean>(20);
		consumers=ibd.listConsumers();
		return consumers;
	}

	@Override
	public List<EBillBean> getConsumerDetails(String consumerNo) {
		IEBilldao ibd=new EBilldao();
		List<EBillBean> consumersdetails=new ArrayList<EBillBean>(20);
		consumersdetails=ibd.getConsumerDetails(consumerNo);
		return consumersdetails;
	}

	@Override
	public List<EBillBean> getBillDetails(String consumerNo) {
		IEBilldao ibd=new EBilldao();
		List<EBillBean> billDetails=new ArrayList<EBillBean>(20);
		billDetails=ibd.getBillDetails(consumerNo);
		return billDetails;
	}


}
