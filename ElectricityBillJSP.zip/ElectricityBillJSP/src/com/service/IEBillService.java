package com.service;

import java.util.List;

import com.bean.EBillBean;

public interface IEBillService {
	List<EBillBean> listConsumers();

	List<EBillBean> getConsumerDetails(String consumerNo);
	List<EBillBean> getBillDetails(String consumerNo);

}
