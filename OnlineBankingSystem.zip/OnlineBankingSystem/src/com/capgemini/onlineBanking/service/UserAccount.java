package com.capgemini.onlineBanking.service;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.onlineBanking.dao.IUserLogin;
import com.capgemini.onlineBanking.dao.UserLoginDB;
import com.capgemini.onlineBanking.exception.onlineBankingException;

public class UserAccount implements IUserAccount{

	@Override
	public String isValidUser(String userName, String pwd) {
		
		String result;
		IUserLogin il=new UserLoginDB();
		result=il.LoginValidation(userName,pwd);
		
		return result;
	}

	@Override
	public boolean getRegistered(String userName, String pwd, long mobile, long accountno, String email) throws onlineBankingException {
		boolean result;
		IUserLogin il=new UserLoginDB();
		result=il.getRegistered(userName,pwd,mobile,accountno,email);
		return false;
	}

	@Override
	public String getMiniStatement(long account) throws ClassNotFoundException, IOException, SQLException {
		String result;
		IUserLogin il=new UserLoginDB();
		result=il.getMiniStatement(account);
		return result;
	}

	@Override
	public boolean validatePayee(long account, long paccount) {
		boolean pdetails;
		IUserLogin il=new UserLoginDB();
		pdetails=il.validatePayee(account,paccount);
		return pdetails;
	}

	@Override
	public boolean transferFund(long account, long paccount, int amount) {
		boolean transferFund;
		IUserLogin il=new UserLoginDB();
		transferFund=il.transferFunds(account,paccount,amount);
		return transferFund;
	}

	@Override
	public void blockAccount(String userName, String pwd) {
		IUserLogin il=new UserLoginDB();
		il.blockAccount(userName,pwd);
		
	}

}
