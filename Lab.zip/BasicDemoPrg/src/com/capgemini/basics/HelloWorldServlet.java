package com.capgemini.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloWorldServlet
 */
@WebServlet("/HelloWorldServlet")
public class HelloWorldServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloWorldServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("pwd");
		String gender=request.getParameter("gender");
		String qualification=request.getParameter("Qualification");
		String[] languages=request.getParameterValues("languages");
		String querystring=request.getQueryString();
		String requestURI=request.getRequestURI();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("Hello world Servlet<br/>");
		out.println("UserName is "+username+"<br/>");
		out.println("Password is "+password+"<br/>");
		out.println("Gender is "+gender+"<br/>");
		out.println("Qualification is "+qualification+"<br/>");
		out.println("The languages known are<br/>");
		
		if(languages!=null){
			for(String language:languages){
				out.println(language+",");
			}
		}
		out.println("<br/>");
		out.println("Query string is         "+querystring+"<br/>");
		out.println("Requested Uri is        "+requestURI+"<br/>");
		Enumeration<String> inputparameters=request.getParameterNames();
		while(inputparameters.hasMoreElements()){
			String param=inputparameters.nextElement();
			out.println(param+",");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
