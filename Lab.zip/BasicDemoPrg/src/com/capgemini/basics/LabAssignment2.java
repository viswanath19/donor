package com.capgemini.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LabAssignment2
 */
@WebServlet("/LabAssignment2")
public class LabAssignment2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LabAssignment2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		 //response.setHeader("Content-Language", "es");
		// response.setHeader("Refresh","2,URL=https://www.flipkart.com");
		boolean result=validateCredentials(username,password);
		
		if(result==true){

			response.sendRedirect("Success.html");
			String MIME=request.getMethod();
			out.println("Successfull Login <br/>"+"Form Method is "+MIME);
			//response.setHeader("Refresh","2;URL=http://localhost:8080/BasicDemoPrg/Success.html");
		}
		else{
			response.sendRedirect("Failure.html");
			String MIME=request.getMethod();
			out.println("Failure Login<br/>"+"Form Method is "+MIME);
			//response.setHeader("Refresh","2;URL=http://localhost:8080/BasicDemoPrg/Failure.html");
		}
	}

	private boolean validateCredentials(String username, String password) {
		String usr="Sharma";
		String pwd="hello";
		boolean result=false;
		if(username.equals(usr)&&password.equals(pwd)){
			result=true;
		}
		else{
			result=false;
		}
		return result;
	}

}
