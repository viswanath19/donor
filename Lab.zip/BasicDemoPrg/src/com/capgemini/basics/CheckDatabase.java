package com.capgemini.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class CheckDatabase
 */
@WebServlet("/CheckDatabase")
public class CheckDatabase extends HttpServlet {
	private static final long serialVersionUID = 1L;  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckDatabase() {
        super();
        // TODO Auto-generated constructor stub
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String ename=request.getParameter("username");
		String eid=request.getParameter("password");
		try{
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select empno from emp where ename='"+ename+"'");
			String password = null;
			//out.println("Employee Names");
			//out.println("<br/>__________________________________<br/>");
			if(rs!=null){
			while(rs.next()){
				password=rs.getString(1);
			}
			}
			//out.println(password);
			if(eid.equals(password)){
				out.println("Successfull Login Welcome "+ename);
			}
			else{
				out.println("Invalid Login Credentials");
			}
		}
		catch(SQLException | NamingException e){
			out.println(e.getMessage());
		}
	}
	/**
	 * 
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
}
