package com.onlinebanking.Dao;

public interface IQueryMapper {
	public static final String GET_ACCOUNTS = "SELECT account_no,user_id,login_password FROM user_table WHERE user_id=?";
	public static final String GET_EMAIL="SELECT EMAIL FROM CUSTOMERS WHERE ACCOUNT_NO=?";
	public static final String UPDATE_EMAIL="UPDATE CUSTOMERS SET EMAIL=? WHERE ACCOUNT_NO=? AND EMAIL=?";
	public static final String GET_ADDRESS="SELECT ADDRESS FROM CUSTOMERS WHERE ACCOUNT_NO=?";
	public static final String UPDATE_ADDRESS="UPDATE CUSTOMERS SET ADDRESS=? WHERE ACCOUNT_NO=? AND ADDRESS=?";
}
