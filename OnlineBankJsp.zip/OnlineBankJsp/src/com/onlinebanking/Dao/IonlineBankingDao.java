package com.onlinebanking.Dao;

import java.util.ArrayList;

import Exception.OnlineBankingException;

public interface IonlineBankingDao {

	ArrayList<Long> getAccounts(long acc_no) throws OnlineBankingException;

	String getEmailId(long accountNo);

	String getEmailId(long acc_no, String email, String existingemail);

	String getAddress(long accountNo);

	String getAddressUpdate(long acc_no, String address, String existingAddress);

}
