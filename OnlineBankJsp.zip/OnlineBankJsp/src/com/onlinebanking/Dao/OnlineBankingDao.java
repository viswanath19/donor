package com.onlinebanking.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;






import Exception.OnlineBankingException;





//import com.onlinebanking.Exception.OnlineBankingException;
import com.onlinebanking.Util.DBUtil;

public class OnlineBankingDao implements IonlineBankingDao{

	@Override
	public ArrayList<Long> getAccounts(long acc_no) throws OnlineBankingException {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		long user_id=0;
		String pwd=null;
		long account_no=0;
		ArrayList<Long> accounts=new ArrayList<Long>();
		
		try{
			con=DBUtil.obtainConnection();
			//stmt=con.createStatement();
			//rs=stmt.executeQuery("select account_no,user_id,login_password from user_table where user_id='"+userId+"' and login_password='"+password+"'");
			st=con.prepareStatement(IQueryMapper.GET_ACCOUNTS);
			st.setLong(1, acc_no);
	
			rs=st.executeQuery();
		
			if(rs!=null){
				while(rs.next()){
					user_id=rs.getLong(2);
					pwd=rs.getString(3);
					account_no=rs.getLong(1);
					accounts.add(account_no);
				}
			}			
		}
		catch(OnlineBankingException e){
			throw new OnlineBankingException("details not fetched");
		}
		catch(Exception e){
			throw new OnlineBankingException("DataBase error");
		}
		return accounts;
	}

	@Override
	public String getEmailId(long accountNo) {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		String email=null;
		try{
			con=DBUtil.obtainConnection();
			st=con.prepareStatement(IQueryMapper.GET_EMAIL);
			st.setLong(1, accountNo);
			rs=st.executeQuery();
			if(rs!=null){
				while(rs.next()){
					email=rs.getString(1);
				}
			}
			if(email==null){
				throw new OnlineBankingException("Email Not Found");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return email;
	}

	@Override
	public String getEmailId(long acc_no, String email, String existingemail) {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		String updateEmail = null;
		try{
			con=DBUtil.obtainConnection();
			st=con.prepareStatement(IQueryMapper.UPDATE_EMAIL);
			st.setString(1, email);
			st.setLong(2, acc_no);
			st.setString(3, existingemail);
			int records=st.executeUpdate();
			if(records>0){
				updateEmail="Updated";
			}
			else{
				throw new OnlineBankingException("Email Not Updated");
			}
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return updateEmail;
	}

	@Override
	public String getAddress(long accountNo) {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		String address=null;
		try{
			con=DBUtil.obtainConnection();
			st=con.prepareStatement(IQueryMapper.GET_ADDRESS);
			st.setLong(1, accountNo);
			rs=st.executeQuery();
			if(rs!=null){
				while(rs.next()){
					address=rs.getString(1);
				}
			}
			if(address==null){
				throw new OnlineBankingException("address Not Found");
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return address;
	}
	@Override
	public String getAddressUpdate(long acc_no, String address, String existingAddress) {
		Connection con=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		String updateAddress = null;
		try{
			con=DBUtil.obtainConnection();
			st=con.prepareStatement(IQueryMapper.UPDATE_ADDRESS);
			st.setString(1, address);
			st.setLong(2, acc_no);
			st.setString(3, existingAddress);
			int records=st.executeUpdate();
			if(records>0){
				updateAddress="Updated";
			}
			else{
				throw new OnlineBankingException("Address Not Updated");
			}
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		return updateAddress;
	}

}
