package com.onlinebanking.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Exception.OnlineBankingException;

import com.onlinebanking.Service.IonlineBankingService;
import com.onlinebanking.Service.OnlineBankingService;

/**
 * Servlet implementation class OnlineBankingController
 */
@WebServlet("/OnlineBankingController")
public class OnlineBankingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OnlineBankingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String operation=request.getParameter("action");
		HttpSession session=null;
		if(operation!=null&&operation.equals("home")){
			long userId=Long.parseLong(request.getParameter("userId"));
			request.setAttribute("userId", userId);
			RequestDispatcher rd=null;
			rd=request.getRequestDispatcher("/home.jsp");
			rd.forward(request, response);
			
		}
		if(operation!=null&&operation.equalsIgnoreCase("updateEmail")){
			//IonlineBankingService ibs=new OnlineBankingService();
			long acc_no=Long.parseLong(request.getParameter("userId"));
			IonlineBankingService ibs=new OnlineBankingService();
			ArrayList<Long> accounts=new ArrayList<Long>();
			try{
			accounts=ibs.getAccounts(acc_no);
			RequestDispatcher rd=null;
			request.setAttribute("accounts",accounts);
			rd=request.getRequestDispatcher("/UpdateEmail.jsp");
			rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
			
		}
		if(operation!=null&&operation.equalsIgnoreCase("EmailUpdate")){
			long accountNo=Long.parseLong(request.getParameter("accountNo"));
			System.out.println(accountNo);
			IonlineBankingService ibs=new OnlineBankingService();
			String email=ibs.getEmailId(accountNo);
			request.setAttribute("emailId", email);
			request.setAttribute("accountNo", accountNo);
			RequestDispatcher rd=null;
			rd=request.getRequestDispatcher("/EmailUpdation.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("ChangeEmail")){
			String email=request.getParameter("emailId");
			long acc_no=Long.parseLong(request.getParameter("accNo"));
			String existingemail=request.getParameter("existingemail");
			//System.out.println(email);
			//System.out.println(acc_no);
			//System.out.println(existingemail)
			IonlineBankingService ibs=new OnlineBankingService();
			String updateEmail=ibs.updateEmail(acc_no,email,existingemail);
			if(updateEmail.equalsIgnoreCase("Updated")){
					RequestDispatcher rd=null;
					PrintWriter out=response.getWriter();
					out.println("updateEmail");
					rd=request.getRequestDispatcher("/EmailUpdation.jsp");
			}
			
			
		}
		else if(operation!=null&&operation.equalsIgnoreCase("updateAddress")){
			long acc_no=Long.parseLong(request.getParameter("userId"));
			System.out.println(acc_no);
			IonlineBankingService ibs=new OnlineBankingService();
			ArrayList<Long> accounts=new ArrayList<Long>();
			try{
			accounts=ibs.getAccounts(acc_no);
			RequestDispatcher rd=null;
			request.setAttribute("accountNumbers",accounts);
			rd=request.getRequestDispatcher("/UpdateAddress.jsp");
			rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
		}
		if(operation!=null&&operation.equalsIgnoreCase("AddressUpdate")){
			long accountNo=Long.parseLong(request.getParameter("accountNo"));
			System.out.println(accountNo);
			IonlineBankingService ibs=new OnlineBankingService();
			String address=ibs.getAddress(accountNo);
			request.setAttribute("Address", address);
			request.setAttribute("accountNo", accountNo);
			RequestDispatcher rd=null;
			rd=request.getRequestDispatcher("/AddressUpdation.jsp");
			rd.forward(request, response);
		}
		if(operation!=null&&operation.equalsIgnoreCase("ChangeAddress")){
			String address=request.getParameter("Address");
			long acc_no=Long.parseLong(request.getParameter("accNo"));
			String existingAddress=request.getParameter("existingAddress");
			//System.out.println(email);
			//System.out.println(acc_no);
			//System.out.println(existingemail)
			IonlineBankingService ibs=new OnlineBankingService();
			String updateAddress=ibs.updateAddress(acc_no,address,existingAddress);
			if(updateAddress.equalsIgnoreCase("Updated")){
					RequestDispatcher rd=null;
					PrintWriter out=response.getWriter();
					out.println("updateAddress");
					rd=request.getRequestDispatcher("/AddressUpdation.jsp");
			}
			
			
		}
	}

}
