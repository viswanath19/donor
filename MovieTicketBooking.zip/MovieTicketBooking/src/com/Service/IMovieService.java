package com.Service;

import java.util.ArrayList;

import com.Bean.Theatre;
import com.Exception.MovieException;

public interface IMovieService {

	ArrayList<String> getMovieNames() throws MovieException;

	ArrayList<Theatre> getTheatreList(String movieName) throws MovieException;

}
