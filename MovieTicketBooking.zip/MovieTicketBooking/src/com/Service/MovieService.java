package com.Service;

import java.util.ArrayList;

import com.Bean.Theatre;
import com.Dao.IMovieDao;
import com.Dao.MovieListDao;
import com.Exception.MovieException;

public class MovieService implements IMovieService{

	@Override
	public ArrayList<String> getMovieNames() throws MovieException{
		IMovieDao imd=new MovieListDao();
		ArrayList<String> movies=imd.getMovieList();
		return movies;
	}

	@Override
	public ArrayList<Theatre> getTheatreList(String movieName) throws MovieException{
		IMovieDao imd=new MovieListDao();
		ArrayList<Theatre> theatres=imd.getTheatreList(movieName);
		
		return theatres;
	}

}
