package com.Dao;

import java.util.ArrayList;

import com.Bean.Theatre;
import com.Exception.MovieException;

public interface IMovieDao {

	ArrayList<String> getMovieList() throws MovieException;

	ArrayList<Theatre> getTheatreList(String movieName) throws MovieException;

}
