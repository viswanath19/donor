package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.Bean.Theatre;
import com.Exception.MovieException;
//import com.igate.moviebooking.dao.String;
import com.util.DBUtil;

public class MovieListDao implements IMovieDao {

	@Override
	public ArrayList<String> getMovieList() throws MovieException {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		ArrayList<String> movieNames=new ArrayList<String>(20);
		try{
			con=DBUtil.obtainConnection();
			stmt=con.createStatement();
			rs=stmt.executeQuery("select movie_name from movies");
			if(rs!=null){
				while(rs.next()){
					movieNames.add(rs.getString(1));
				}
			}
		}
		catch(SQLException e){
			throw new MovieException("Error while interaction with datasource");
		}
		return movieNames;
	}

	@Override
	public ArrayList<Theatre> getTheatreList(String movieName) throws MovieException {
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		ArrayList<Theatre> theatreList=new ArrayList<Theatre>(20);
		try{
			con=DBUtil.obtainConnection();
			stmt=con.createStatement();
			PreparedStatement pmstmt=null;
			String sql="SELECT theaterId,theaterName,AvailableTickets,moviePlayTime,price FROM movies m,theaters t WHERE m.movieId=t.movieId AND movie_Name=?";
			pmstmt=con.prepareStatement(sql);
			pmstmt.setString(1, movieName);
			rs=pmstmt.executeQuery();
			System.out.println("hello");
			System.out.println(movieName);
			if(rs!=null){
				while(rs.next()){
					Theatre th=new Theatre();
					th.setTheaterId(rs.getInt("theaterId"));
					th.setTheaterName(rs.getString("theaterName"));
					th.setAvailableTickets(rs.getInt("AvailableTickets"));
					th.setMoviePlayTime(rs.getTimestamp("moviePlayTime"));
					th.setTicketPrice(rs.getDouble("price"));
					theatreList.add(th);
				}
			}
		}
		catch(SQLException e){
			throw new MovieException("Error while interaction with datasource");
		}
		return theatreList;
		
	}

}
