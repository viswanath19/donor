package com.Exception;

public class MovieException extends Exception{
	public MovieException(String msg){
		super(msg);
	}

}
