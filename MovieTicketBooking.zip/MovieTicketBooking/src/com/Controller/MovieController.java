package com.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Bean.Theatre;
import com.Exception.MovieException;
import com.Service.IMovieService;
import com.Service.MovieService;

/**
 * Servlet implementation class MovieController
 */
@WebServlet("/MovieController")
public class MovieController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MovieController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd=null;
		IMovieService ims=new MovieService();
		String operation=request.getParameter("action");
		HttpSession session=request.getSession(false);
		if(operation!=null&&operation.equals("fetchMovies")){
			try{
				ArrayList<String> movieNames=ims.getMovieNames();
				request.setAttribute("moviesList", movieNames);
				rd=request.getRequestDispatcher("/movieList.jsp");
				rd.forward(request, response);
			}
			catch(MovieException e){
				PrintWriter out=response.getWriter();
				out.println(e.getMessage());
			}
		}
		if(operation!=null&&operation.equalsIgnoreCase("search")){
			String movieName=request.getParameter("movies");
			//System.out.println(movieName);
			if(session==null){
				session=request.getSession(true);
			}
			session.setAttribute("movieName", movieName);
			try{
				ArrayList<Theatre> theatre=ims.getTheatreList(movieName);
				
				request.setAttribute("theatres",theatre);
				PrintWriter out=response.getWriter();
				out.println(theatre);
				rd=request.getRequestDispatcher("/theatres.jsp");
				rd.forward(request,response);
			}
			catch(MovieException e){
				PrintWriter out=response.getWriter();
				out.println(e.getMessage());
			}
		}
	}

}
