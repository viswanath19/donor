package com.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.Exception.MovieException;

public class DBUtil {
	public static Connection connection;
	public static Connection obtainConnection()throws MovieException{
	try{
		InitialContext ic=new InitialContext();
		DataSource ds=ic.doLookup("java:/OracleDs");
		connection=ds.getConnection();
	}
	catch(NamingException e){
		throw new MovieException("Error while creating DataSources");
	}
	catch(SQLException e){
		throw new MovieException("Error while obtaining DataSource Connection");
	}
	return connection;
}
}
