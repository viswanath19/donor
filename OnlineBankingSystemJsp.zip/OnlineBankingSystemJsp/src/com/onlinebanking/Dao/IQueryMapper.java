package com.onlinebanking.Dao;

public interface IQueryMapper {
	public static final String miniStatement="select account_no,transamount,transaction_id,transaction_date from transactions where account_no=? and rownum<=5";
	public static final String GET_ACCOUNTS = "SELECT account_no,user_id,login_password FROM user_table WHERE user_id=?";
	public static final String USER_DETAILS="SELECT user_table.user_id,user_table.login_password,customers.customer_name FROM account_master,customers,user_table WHERE account_master.account_no=user_table.account_no AND customers.account_no=account_master.account_no AND user_table.lock_status='U'";
	public static final String INSERT_DETAILS= "INSERT INTO user_table VALUES(?,?,?,?,?,?,'L')";
	public static final String detailedStatement="select account_no,transamount,transaction_id,transaction_date from transactions where account_no=? and transaction_date between ? and ?";
}
