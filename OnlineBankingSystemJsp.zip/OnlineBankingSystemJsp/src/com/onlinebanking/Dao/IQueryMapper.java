package com.onlinebanking.Dao;

public interface IQueryMapper {
	
	public static final String MINI_STATEMENT="SELECT account_no,trans_amount,transaction_id,transaction_date FROM transactions WHERE account_no=? AND rownum<=5";
	
	public static final String GET_ACCOUNTS = "SELECT account_no,user_id,login_password FROM user_table WHERE user_id=?";
	
	public static final String USER_DETAILS="SELECT user_table.user_id,user_table.login_password,customer.customer_name FROM account_master,customer,user_table WHERE account_master.account_no=user_table.account_no AND customer.account_no=account_master.account_no AND user_table.lock_status='U'";
	
	public static final String INSERT_DETAILS= "INSERT INTO user_table VALUES(?,?,?,?,?,?,'L')";

	public static final String DETAIL_STATEMENT="SELECT account_no,trans_amount,transaction_id,transaction_date FROM transactions WHERE account_no=? AND transaction_date BETWEEN ? AND ?";

	public static final String GET_EMAIL="SELECT mobileno FROM customers WHERE account_no=?";
	
	public static final String UPDATE_EMAIL="UPDATE customer SET mobileno=? WHERE account_no=? AND mobileno=?";
	
	public static final String GET_ADDRESS="SELECT address FROM customer WHERE account_no=?";
	
	public static final String UPDATE_ADDRESS="UPDATE customer SET address=? WHERE account_no=? AND address=?";

	public static final String BLOCK_USERID="UPDATE user_table SET lock_status='l' WHERE user_id=?";
	
	public static final String GET_SECRET_INFO ="SELECT secret_question,secret_answer FROM user_table WHERE user_id=?";
	
	public static final String UPDATE_PWD = "UPDATE user_table SET login_password=? WHERE user_id=?";

	public static final String transaction_id="select trans_seq_id.nextVal from dual";
	
	public static final String transaction_password="select transaction_password from user_table where account_no=?";
	
	public static final String AccountServiceDetails="SELECT * FROM SERVICE_TRACKER WHERE account_no=?";
	
	public static final String CreateAccount="insert into account_master values(?,?,?,SYSDATE)";
	
	public static final String AccountSequence="select seq_acc_num.nextval from dual";
	
	public static final String customerDetails="insert into customer values(?,?,?,?,?)";
	
	public static final String YearlyTransactions="select * from transactions where extract(year from transaction_date)=?";
	
	public static final String MonthlyTransactions="select * from transactions where extract(month from transaction_date)=?";
	
	public static final String DailyTransactions="select * from transactions where extract(day from transaction_date)=?";
	
	public static final String RAISECHECKBOOK="INSERT INTO SERVICE_TRACKER VALUES(?,?,?,SYSDATE,?)";
	
	public static final String SER_SEQ_ID="SELECT SER_SEQ_ID.NEXTVAL FROM DUAL";
	
	public static final String SERVICE_REQUEST_DETAILS="SELECT * FROM SERVICE_TRACKER WHERE SERVICE_ID=?";
	
	public static final String payeeAccounts="select payee_table.payee_account_no from payee_table payee_table,user_table user_table where user_table.user_id=? and user_table.account_no=payee_table.account_no";
	
	public static final String updateUserAccount="UPDATE account_master set account_balance=? where account_no=?";
	
	public static final String accountBalance="select account_balance from account_master where account_no=?";
	
	public static final String updateUserTransaction="insert into transactions values(?,?,SYSDATE,?,?,?)";
}
