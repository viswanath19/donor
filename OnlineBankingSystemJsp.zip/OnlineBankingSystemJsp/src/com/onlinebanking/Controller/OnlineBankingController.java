package com.onlinebanking.Controller;

import java.awt.print.Printable;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletContext;




import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Exception.OnlineBankingException;
import com.onlinebanking.Service.IonlineBankingService;
import com.onlinebanking.Service.OnlineBankingService;

/**
 * Servlet implementation class OnlineBankingController
 */
@WebServlet("/OnlineBankingController")
public class OnlineBankingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    static int count=0; 
    static ArrayList<Long> userIds = new ArrayList<Long>();
    static long userId = 0;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OnlineBankingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = null;
		OnlineBankingBean bean = new OnlineBankingBean();
		PrintWriter out = response.getWriter();
		RequestDispatcher rd=null;
		String operation=request.getParameter("action");
		if(operation==null){
			operation="Nan";
		}
		//System.out.println("Operation =" + operation);
		String options=request.getParameter("name");
		//System.out.println(options);
		IonlineBankingService ibs=new OnlineBankingService();
		ArrayList<Long> accounts=new ArrayList<Long>();
		
		try{
		if(operation!=null && operation.equalsIgnoreCase("Login")){
			
			//System.out.println("Reached login");
			session = request.getSession(true);
			userId=Long.parseLong(request.getParameter("userID"));		
			String pwd=request.getParameter("pwd");
			try {
				if(userId==12345l && pwd.equals("admin")){
					session.setAttribute("uname", "admin");
					session.setAttribute("userId", Long.toString(userId));
					//System.out.println("Reached session");
					ServletContext context = getServletContext();
					rd = context.getRequestDispatcher("/homeAdmin.jsp");
					rd.include(request, response);
				}
				else{
					String result = ibs.validateUser(userId, pwd);
					if(!result.equals("fail")){
						accounts=ibs.getAccounts(userId);
						session.setAttribute("uname", result);
						session.setAttribute("userId", userId);
						session.setAttribute("accounts",accounts);
						ServletContext context = getServletContext();
						rd = context.getRequestDispatcher("/homeUser.jsp");
						rd.include(request, response);
					}
					else{
					//	System.out.println("Reached else part");
						userIds.add(userId);
						Set<Long> unique = new HashSet<Long>(userIds);
						for (Long key : unique) {
							if( Collections.frequency(userIds, key)>3){
								ibs.blockUserId(key);
								request.setAttribute("uId", key);
								ServletContext context = getServletContext();
								rd = context.getRequestDispatcher("/Block.jsp");
								rd.forward(request, response);
							}
						  //  System.out.println(key + ": " + Collections.frequency(userIds, key));
						}
						session.setAttribute("uname", "fail");
						//System.out.println("\n\nreached else\n\n");
						ServletContext context = getServletContext();
						rd = context.getRequestDispatcher("/Login.jsp");
						rd.include(request, response);
					}
				}
			} 
			catch (Exception e) {
				System.out.println(e.getMessage());
				ServletContext context = getServletContext();
				rd = context.getRequestDispatcher("/Error.jsp");
				rd.forward(request, response);
			}
		}
		else if(options!=null&&options.equalsIgnoreCase("FetchAccounts")){
			
			long acc_no=Long.parseLong(request.getParameter("userId"));
		
			try{
				accounts=ibs.getAccounts(acc_no);
				request.setAttribute("accounts",accounts);
				rd=request.getRequestDispatcher("/FetchAccounts.jsp");
				rd.include(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
		}
		else if(options!=null&&options.equalsIgnoreCase("FetchDetailedAccounts")){
		
			long acc_no=Long.parseLong(request.getParameter("userId"));
			System.out.println("FechDetailed Accounts");
			try{
				accounts=ibs.getAccounts(acc_no);
				request.setAttribute("accounts",accounts);
				rd=request.getRequestDispatcher("/FetchDetailedAccounts.jsp");
				rd.include(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
		
		}
		else if(operation!=null&&operation.equals("viewDetailedStatement")){
			System.out.println("Inside Detailed statement");
			long accountNo=Long.parseLong(request.getParameter("account"));
			System.out.println(accountNo);
			request.setAttribute("acc_no", accountNo);
			rd=request.getRequestDispatcher("/DetailedStatement.jsp");
			rd.include(request, response);
			
		}
		else if(operation!=null&&operation.equals("viewMiniStatement")){
			long accountNo=Long.parseLong(request.getParameter("account"));
			
			try {
				ArrayList<OnlineBankingBean> miniStatement=ibs.getMiniStatement(accountNo);
				//System.out.println("Accounts: "+miniStatement);
				for(OnlineBankingBean b : miniStatement)
					System.out.println("TransId : " + b.getTransactionId());
				request.setAttribute("miniStatement", miniStatement);
				rd=request.getRequestDispatcher("/ViewMiniStatement.jsp");
				rd.forward(request, response);
			} catch (OnlineBankingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else if(operation!=null&&operation.equals("GetDetailedStatement")){
			//System.out.println(request.getAttribute("accountNo"));
			//System.out.println(acc_no);
			try{
				long acc_no=Long.parseLong(request.getParameter("account"));
				String fromDate=request.getParameter("fromDate");
				String toDate=request.getParameter("toDate");
				
				//System.out.println(date);
					ArrayList<OnlineBankingBean> detailedStatement=ibs.getDetailedStatement(acc_no,fromDate,toDate);
				//	System.out.println(detailedStatement);
					request.setAttribute("detailedStatement", detailedStatement);
					rd=request.getRequestDispatcher("/ViewDetailedStatement.jsp");
					rd.forward(request, response);
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		else if(operation!=null && operation.equals("register")){
			System.out.println("Reached : " + operation);
			try {
				long accNum = Long.parseLong(request.getParameter("accNum"));
				userId = Long.parseLong(request.getParameter("userId"));
				String pwd = request.getParameter("loginPwd");
				String color = request.getParameter("color");
				String transPwd = request.getParameter("transPwd");
				String question = request.getParameter("question");
				
				bean.setAccountNo(accNum);
				bean.setUserId(userId);
				bean.setLoginPwd(pwd);
				bean.setTransPwd(transPwd);
				bean.setColor(color);
				bean.setStatus("L");
				//System.out.println("before method call");
				boolean result = ibs.getRegistered(bean);
				//System.out.println("after method call");
				if(result==false){
					out.println("Failed to Register User....");
				}
				else{
					out.println("Registration Successfull....");
				}
			} 
			catch (Exception e) {
				System.out.println(e.getMessage());
				ServletContext context = getServletContext();
				rd = context.getRequestDispatcher("/Error.jsp");
				rd.forward(request, response);
			}
			
		}
		else if(options!=null&&options.equalsIgnoreCase("updateEmail")){
			//IonlineBankingService ibs=new OnlineBankingService();
			//long acc_no=(long) session.getAttribute("userId");
			long acc_no=Long.parseLong(request.getParameter("userId"));
		//	ArrayList<Long> accounts=new ArrayList<Long>();
			//System.out.println("Update Email");
			try{
				accounts=ibs.getAccounts(acc_no);
	
				request.setAttribute("accounts",accounts);
				rd=request.getRequestDispatcher("/UpdateEmail.jsp");
				rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
			
		}
		if(operation!=null&&operation.equalsIgnoreCase("EmailUpdate")){
			long accountNo=Long.parseLong(request.getParameter("accountNo"));
			System.out.println(accountNo);
			ibs=new OnlineBankingService();
			String email=ibs.getEmailId(accountNo);
			System.out.println(email);
			request.setAttribute("emailId", email);
			request.setAttribute("accountNo", accountNo);
			rd=request.getRequestDispatcher("/EmailUpdation.jsp");
			rd.forward(request, response);
		}
		else if(operation!=null&&operation.equalsIgnoreCase("ChangeMobileno")){
			String email=request.getParameter("emailId");
			System.out.println(email);
			long acc_no=Long.parseLong(request.getParameter("accNo"));
			String existingemail=request.getParameter("oldmobno");
			
			String updatemobile = null;
			try {
				updatemobile = ibs.updatemobilenum(acc_no,email,existingemail);
			} catch (OnlineBankingException e) {
				System.out.println(e.getMessage());
			}
			if(updatemobile.equalsIgnoreCase("Updated")){
					out.println("updateEmail");
					rd=request.getRequestDispatcher("/EmailUpdation.jsp");
			}
			
			
		}
		else if(options!=null&&options.equalsIgnoreCase("updateAddress")){
			long acc_no=Long.parseLong(request.getParameter("userId"));
			
			
			//ArrayList<Long> accounts=new ArrayList<Long>();
			try{
			accounts=ibs.getAccounts(acc_no);
			
			request.setAttribute("accountNumbers",accounts);
			rd=request.getRequestDispatcher("/UpdateAddress.jsp");
			rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
		}
		else if(operation!=null&&operation.equalsIgnoreCase("AddressUpdate")){
			long accountNo=Long.parseLong(request.getParameter("accountNo"));
			//System.out.println(accountNo);
			
			String address = null;
			try {
				address = ibs.getAddress(accountNo);
			} 
			catch (OnlineBankingException e) {
				System.out.println(e.getMessage());
			}
			request.setAttribute("Address", address);
			request.setAttribute("accountNo", accountNo);
			
			rd=request.getRequestDispatcher("/AddressUpdation.jsp");
			rd.forward(request, response);
		}
		else if(operation!=null&&operation.equalsIgnoreCase("ChangeAddress")){
			String address=request.getParameter("Address");
			long acc_no=Long.parseLong(request.getParameter("accNo"));
			String existingAddress=request.getParameter("existingAddress");
			
			String updateAddress = null;
			try {
				updateAddress = ibs.updateAddress(acc_no,address,existingAddress);
			} 
			catch (OnlineBankingException e) {
				System.out.println(e.getMessage());
			}
			if(updateAddress.equalsIgnoreCase("Updated")){			
					out.println("updateAddress");
					rd=request.getRequestDispatcher("/AddressUpdation.jsp");
					rd.forward(request, response);
			}
		}
		else if(operation!=null && operation.equals("Change Password")){
		
			String question = request.getParameter("question");
			String answer = request.getParameter("answer");
			//System.out.println("change Password..."+userId);
			//out.println(question);
			//out.println(answer);
			String result = null;
			try {
				result = ibs.validateSecretAnswer(question,answer,userId);//userId
			} catch (OnlineBankingException e) {
				System.out.println(e.getMessage());
			}
			
			if(result.equals("success")){
				//System.out.println("reached success");
				rd=request.getRequestDispatcher("/passwordChange.jsp");
				rd.forward(request, response);
			}
			else out.println("Wrong Input.....");
			
			
		}
		else if(operation!=null && operation.equals("Update Password")){
			long uid = Long.parseLong(request.getParameter("userID"));
			String question = request.getParameter("question");
			String answer = request.getParameter("answer");
			userId=uid;
			//System.out.println("change Password..."+userId);
			//out.println(question);
			//out.println(answer);
			String result = null;
			try {
				result = ibs.validateSecretAnswer(question,answer,uid);//userId
			} catch (OnlineBankingException e) {
				System.out.println(e.getMessage());
			}
			
			if(result.equals("success")){
				//System.out.println("reached success");
				rd=request.getRequestDispatcher("/passwordChange.jsp");
				rd.forward(request, response);
			}
			else out.println("Wrong Input.....");
		}
		else if(operation!=null && operation.equals("updatePwd")){
			String newPwd = request.getParameter("newPwd");
			String rePwd = request.getParameter("rePwd");
			String result = "fail";
			
			if(rePwd.equals(newPwd)){
				try {
					result= ibs.changePassword(newPwd,userId);
				} 
				catch (OnlineBankingException e) {
					System.out.println(e.getMessage());
				}
				if(result.equals("success")){
					out.println("Password Update Successfully");
				}
				else{
					out.println("Failed to Update Password");
				}
			}
		}
		else if(options!=null&&options.equalsIgnoreCase("RequestforCheckBook")){
		//	System.out.println("In RequestforCheckBook");
			long acc_no=Long.parseLong(request.getParameter("userId"));
		//	System.out.println(acc_no);
			
			//ArrayList<Long> accounts=new ArrayList<Long>();
			try{
			accounts=ibs.getAccounts(acc_no);
			rd=null;
			request.setAttribute("accounts",accounts);
			rd=request.getRequestDispatcher("/CheckBookAccounts.jsp");
			rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
		}
		else if(operation!=null&&operation.equalsIgnoreCase("RaiseRequest")){
			//System.out.println("In RaiseRequest");
			long accountNo=Long.parseLong(request.getParameter("account"));
			String description=request.getParameter("description");
			
			String raiseCheckBookRequest = null;
			try {
				raiseCheckBookRequest = ibs.raiseCheckBookRequest(accountNo,description);
			} 
			catch (OnlineBankingException e) {
				System.out.println(e.getMessage());
			}
			//System.out.println("Service Id : " + raiseCheckBookRequest);
			request.setAttribute("checkBookRequest", raiseCheckBookRequest);
			rd=request.getRequestDispatcher("/CheckBookService.jsp");
			rd.forward(request, response);
		}
		else if(options!=null&&options.equalsIgnoreCase("TrackCheckBookRequest")){
			//System.out.println("In TrackCheckBookRequest");
			long userId=Long.parseLong(request.getParameter("userId"));
			request.setAttribute("userId", userId);
			rd=request.getRequestDispatcher("/TrackCheckBookRequest.jsp");
			rd.forward(request, response);
		}
		else if(operation!=null&&operation.equalsIgnoreCase("TrackService")){
		//	System.out.println("In TrackService");
			long service_id=Long.parseLong(request.getParameter("serviceId"));
			ArrayList<OnlineBankingBean> serviceRequestDetails=new ArrayList<OnlineBankingBean>();
			try {
				serviceRequestDetails=ibs.getCheckBookService(service_id);
			}
			catch (OnlineBankingException e) {
				System.out.println(e.getMessage());
			}
			request.setAttribute("checkBookDetails", serviceRequestDetails);
			rd=request.getRequestDispatcher("/ServiceRequestDetails.jsp");
			rd.forward(request, response);
		}
		else if(options!=null&&options.equalsIgnoreCase("fundTransfer")){
			String userId=request.getParameter("userId");
			long uid=Long.parseLong(userId);
			
			
			ArrayList<Long> GetAccounts=new ArrayList<Long>();
			ArrayList<Long> PayeeAccounts=new ArrayList<Long>();
			try{
				GetAccounts=ibs.getAccounts(uid);
				PayeeAccounts=ibs.getPayeeAccounts(uid);
				request.setAttribute("UserAccounts", GetAccounts);
				request.setAttribute("PayeeAccounts", PayeeAccounts);
				rd=request.getRequestDispatcher("/FundTransfer.jsp");
				rd.forward(request, response);
			}
			catch(OnlineBankingException e){
				System.out.println(e.getMessage());
			}
			//out.println(userId);
		}
		else if(operation!=null&operation.equalsIgnoreCase("transferFunds")){
			long accountNo=Long.parseLong(request.getParameter("UserAccounts"));
			long payeeAccount=Long.parseLong(request.getParameter("PayeeAccount"));
			String transferDesc=request.getParameter("transferDesc");
			long amount=Long.parseLong(request.getParameter("fund"));
			String transpwd=request.getParameter("transpwd");
			
			String fundTransfer = null;
			try {
				fundTransfer = ibs.transferFunds(accountNo,payeeAccount,transferDesc,amount,transpwd);
				System.out.println(fundTransfer);
			} 
			catch (OnlineBankingException e) {
				System.out.println(e.getMessage());
			}
			if(fundTransfer.equalsIgnoreCase("success")){
				request.setAttribute("transferFund", fundTransfer);
				rd=request.getRequestDispatcher("/Success.jsp");
				rd.forward(request, response);
			}
			else{
					request.setAttribute("msg", "fund transfer failed");
					rd=request.getRequestDispatcher("/Error.jsp");
					rd.forward(request, response);
				}
			
		}
		else if(options!=null&&options.equalsIgnoreCase("TrackRequestOnAcount")){
			long uid=Long.parseLong(request.getParameter("userId"));
			//System.out.println(uid);
			System.out.println("In TrackRequestOnAcount");
			//GetAccounts=ibs.getAccounts(userId);
		
			ArrayList<Long> GetAccounts=new ArrayList<Long>();

			GetAccounts=ibs.getAccounts(uid);
			request.setAttribute("UserAccounts", GetAccounts);
			rd=request.getRequestDispatcher("/TrackServiceByAccount.jsp");
			rd.forward(request, response);
			
		}
		else if(operation!=null&&operation.equalsIgnoreCase("trackServiceRequest")){
			long acc_no=Long.parseLong(request.getParameter("UserAccounts"));
			//System.out.println(acc_no);
			//System.out.println("In trackServiceRequest");
			ArrayList<OnlineBankingBean> serviceRequestDetails=new ArrayList<OnlineBankingBean>();
			try {
				serviceRequestDetails=ibs.getCheckBookAccountService(acc_no);
			}
			catch (OnlineBankingException e) {
				System.out.println(e.getMessage());
			}
			
			request.setAttribute("checkBookDetails", serviceRequestDetails);
			rd=request.getRequestDispatcher("/AccountServiceRequestDetails.jsp");
			rd.forward(request, response);
		}
		else if(options!=null&&options.equalsIgnoreCase("createAccounts")){
			
			rd=request.getRequestDispatcher("/createNewAccounts.jsp");
			rd.forward(request, response);
		}
		else if(options!=null&&options.equalsIgnoreCase("viewTransactions")){
			
			rd=request.getRequestDispatcher("/viewTransactions.jsp");
			rd.forward(request, response);
		}
		else if(options!=null&&options.equalsIgnoreCase("viewBlockedAccounts")){
			
			rd=request.getRequestDispatcher("/viewBlockedAccounts.jsp");
			rd.forward(request, response);
		}
		else if(operation!=null&&operation.equalsIgnoreCase("CreateAccount")){
			String name=request.getParameter("cname");
			String address=request.getParameter("address");
			String mobileno=request.getParameter("mobile");
			String accountType=request.getParameter("Accounttype");
			long balance=Long.parseLong(request.getParameter("balance"));
			String panno=request.getParameter("panno");
			
			OnlineBankingBean ob=new OnlineBankingBean();
			ob.setName(name);
			ob.setAddress(address);
			ob.setMobileno(mobileno);
			ob.setAccountType(accountType);
			ob.setOpeningBalance(balance);
			ob.setPanno(panno);
			
			
			String createAccount = null;
			try {
				createAccount = ibs.createAccount(ob);
			} catch (OnlineBankingException e) {
				System.out.println(e.getMessage());
			}
			
			if(createAccount!=null){
				out.println("Account Created Successfully with Account no"+createAccount);
			}
			else{
				System.out.println("Account not created");
			}
			
		}
		else if(operation!=null&&operation.equalsIgnoreCase("viewTransactionHistory")){
			String option=request.getParameter("viewTransactions");
		
			if(option.equals("YearlyTransactions")){
				   int year = Calendar.getInstance().get(Calendar.YEAR);
				   //System.out.println(year);
				   ArrayList<OnlineBankingBean> transactionYear=new ArrayList<OnlineBankingBean>();
				  
				  try {
					transactionYear=ibs.getYearlyTransaction(year);
				} 
				  catch (OnlineBankingException e) {
					System.out.println(e.getMessage());
				}
				  // System.out.println(transactionYear);
				   request.setAttribute("Transactions", transactionYear);
				   request.setAttribute("TransactionHistory", "Yearly Transactions");
				   rd=request.getRequestDispatcher("/transactionHistory.jsp");
				   rd.forward(request, response);
			}
			else if(option.equals("MonthlyTransactions")){
				int month = Calendar.getInstance().get(Calendar.MONTH);
				ArrayList<OnlineBankingBean> transactionMonth=new ArrayList<OnlineBankingBean>();
				
				try {
					transactionMonth=ibs.getMonthlyTransaction(month);
				} 
				catch (OnlineBankingException e) {
					System.out.println(e.getMessage());
				}
				request.setAttribute("Transactions", transactionMonth);
				request.setAttribute("TransactionHistory", "Monthly Transactions");
				rd=request.getRequestDispatcher("/transactionHistory.jsp");
				rd.forward(request, response);
				
			}
			else if(option.equals("DailyTransactions")){
				int date = Calendar.getInstance().get(Calendar.DATE);
				ArrayList<OnlineBankingBean> transactionDate=new ArrayList<OnlineBankingBean>();
				
				try {
					transactionDate=ibs.getDailyTransaction(date);
				} 
				catch (OnlineBankingException e) {
					System.out.println(e.getMessage());
				}
				request.setAttribute("Transactions", transactionDate);
				request.setAttribute("TransactionHistory", "Daily Transactions");
				rd=request.getRequestDispatcher("/transactionHistory.jsp");
				rd.forward(request, response);
				
			}
		}
	}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}