package com.onlinebanking.Service;

import java.sql.SQLException;
import java.util.ArrayList;


import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Exception.OnlineBankingException;

public interface IonlineBankingService {

	ArrayList<Long> getAccounts(long userId) throws OnlineBankingException;

	ArrayList<OnlineBankingBean> getMiniStatement(String acc_no) throws OnlineBankingException;
	
	public abstract String validateUser(long userId, String pwd) throws OnlineBankingException, SQLException;
	
	boolean getRegistered(OnlineBankingBean userbean) throws OnlineBankingException, SQLException;

	ArrayList<OnlineBankingBean> getDetailedStatement(long acc_no,String fromDate,String toDate);

}
