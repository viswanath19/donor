package com.onlinebanking.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Dao.IonlineBankingDao;
import com.onlinebanking.Dao.OnlineBankingDao;
import com.onlinebanking.Exception.OnlineBankingException;

public class OnlineBankingService implements IonlineBankingService{

	@Override
	public ArrayList<Long> getAccounts(long userId) throws OnlineBankingException{
		IonlineBankingDao ibd=new OnlineBankingDao();
		
		ArrayList<Long> accounts=ibd.getAccounts(userId);
		
		return accounts;
	}

	@Override
	public ArrayList<OnlineBankingBean> getMiniStatement(String acc_no) throws OnlineBankingException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> miniStatement=ibd.getMiniStatement(acc_no);
		return miniStatement;
	}
	
	@Override
	public String validateUser(long userId, String password) throws OnlineBankingException, SQLException {
		
		IonlineBankingDao ibd=new OnlineBankingDao();
		String result = ibd.validateUser(userId, password);
		
		return result;
	}

	@Override
	public boolean getRegistered(OnlineBankingBean userbean)
			throws OnlineBankingException, SQLException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		boolean result = ibd.getRegistered(userbean);
		return result;
	}

	@Override
	public ArrayList<OnlineBankingBean> getDetailedStatement(long acc_no,String fromDate,String toDate) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> detailedStatement=ibd.getdetailedStatement(acc_no,fromDate,toDate);
		return detailedStatement;// TODO Auto-generated method stub
		
	}

}
